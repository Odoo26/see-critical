from odoo import fields, models


class Affaire(models.Model):
    _inherit = "helpdesk.ticket"
    
    
    RMA = fields.Char(string='RMA')
    
 