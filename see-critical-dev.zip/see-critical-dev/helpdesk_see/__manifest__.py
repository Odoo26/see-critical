{
    'name':'Solution Ticketing pour See',
    'description':'Gérer les tickets de support',
    'author':'JULIA Gilles',
    'license': "AGPL-3",
    'depends':['helpdesk'],
    'data': [
    'views/helpdesksee.xml',
    ],
    'application':False,
}