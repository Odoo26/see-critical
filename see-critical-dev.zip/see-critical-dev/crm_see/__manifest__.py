{
    'name':'Solution CRM pour See',
    'description':'Gérer les contacts commerciaux',
    'author':'JULIA Gilles',
    'license': "AGPL-3",
    'depends':['crm'],
    'data': [
    'views/see.xml',
    'data/data.xml',
    ],
    'application':False,
}